import 'package:flutter_test/flutter_test.dart';
import 'package:moon_cosmetics_pos/app.dart';

void main() {
  testWidgets('Moon Cosmetics POS app starts', (WidgetTester tester) async {
    await tester.pumpWidget(const MoonCosmeticsApp());
    await tester.pumpAndSettle();

    expect(find.text('Dashboard'), findsOneWidget);
  });
}
