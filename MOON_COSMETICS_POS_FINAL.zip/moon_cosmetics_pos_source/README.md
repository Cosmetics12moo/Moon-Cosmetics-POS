# Moon Cosmetics & Beauty Shop POS — Reconstructed Source

This is a clean-room reconstruction of the supplied Flutter Windows POS. It is NOT a recovery of the original developer's Dart source: the supplied package contains a stripped AOT `data/app.so` and compiled Windows runtime files, but no original `lib/*.dart` source.

The reconstruction uses the supplied database migrations and binary string evidence to create a new cosmetics-retail codebase.

## Removed from the new model
- Mobile / Used Mobile
- IMEI / IMEI2
- PTA / Network status
- RAM / storage / mobile variants
- Repair / technicians
- Accessories module and accessory-specific pricing

## Added/retained for cosmetics retail
- Moon Cosmetics & Beauty Shop branding and invoice logo
- Custom categories (add/edit/deactivate)
- Product, brand, shade/variant and barcode fields
- Batch and expiry tracking
- Purchase and stock foundation
- POS sales foundation
- Customer and supplier ledgers
- Expenses/accounts
- Profit/stock report foundation
- PDF invoice/printing foundation

## Important build note
The Flutter SDK was not available in the analysis environment, so this source package was not compiled here. Before production use, run `flutter pub get`, generate platform folders with `flutter create .`, configure the database, apply the SQL migration, and test every business workflow.
