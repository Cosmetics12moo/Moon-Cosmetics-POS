import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:moon_cosmetics_pos/app.dart';

void main() {
  testWidgets('App loads and shows the Dashboard tab', (WidgetTester tester) async {
    await tester.pumpWidget(const MoonCosmeticsApp());
    await tester.pumpAndSettle();

    expect(find.text('Dashboard'), findsOneWidget);
  });
}
